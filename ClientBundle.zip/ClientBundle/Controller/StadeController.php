<?php

namespace ClientBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class StadeController extends Controller
{
    public function indexAction()
    {
        return $this->render('ClientBundle:Stade:index.html.twig', array(
            // ...
        ));
    }

}
