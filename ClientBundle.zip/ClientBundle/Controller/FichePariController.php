<?php

namespace ClientBundle\Controller;

use ClientBundle\ClientBundle;
use ClientBundle\Entity\FichePari;
use ClientBundle\Entity\Pari;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class FichePariController extends Controller
{
    public function indexAction()
    {

        return $this->render('ClientBundle:FichePari:index.html.twig', array(// ...
        ));


    }

    public function AjouterAction(Request $request)
    {
        $fp = new FichePari();
        $m = 0;
        if ($request->isMethod('POST')) {
            //Récupération des valeurs à partir du formulaire
            if (isset($_POST['simple'])) {
                foreach ($request->get('idmatch') as $k => $item) {
                    $mise = $request->get('amisesimple')[$k];
                    $m += $mise;
                }

                if (($this->getUser()->getJeton()) >= $m) {
                    foreach ($request->get('idmatch') as $k => $item) {
                        $em = $this->getDoctrine()->getManager();
                        $resultat = $request->get('sresultats')[$k];
                        $gain = $request->get('againsimple')[$k];
                        $mise = $request->get('amisesimple')[$k];
                        $cote = $request->get('cotes')[$k];
                        $fp = new FichePari();
                        $fp->setDate(new \DateTime('now'));
                        $fp->setEtat("Encours");
                        $fp->setType(0);
                        $fp->setIdUser($this->getUser());
                        $fp->setGain($gain);
                        $fp->setMisetotal($mise);
                        $fp->setCotetotal($cote);
                        $em->persist($fp);
                        $em->flush();
                        $p = new Pari();
                        $p->setGain($gain);
                        $p->setCote($cote);
                        $p->setIdFichePari($fp);
                        $p->setType(0);
                        $p->setEtat("Encours");
                        if ($resultat == "X") {
                            $p->setResultat("X");
                        } else if ($resultat == "1") {
                            $p->setResultat("un");
                        } else if ($resultat == "2") {
                            $p->setResultat("deux");
                        }
                        $p->setCote($cote);
                        $p->setType(0);
                        $p->setGain($gain);
                        $p->setMise($mise);
                        $match = $em->getRepository("ClientBundle:Match2018")->find($item);

                        $p->setIdMatch($match);
                        $p->setIdFichePari($fp);
                        $em->persist($p);
                        $em->flush();
                       /* $number="21628428425";
                        $message="nemchiw neklou?";
                        $fromName="bouhmid";
                        $sender = $this->container->get('jhg_nexmo_sms');
                        $sender->sendText($number, $message, $fromName);*/
                    }
                    $this->getUser()->setJeton($this->getUser()->getJeton() - $m);
                    $em->persist($this->getUser());
                    $em->flush();

                } else {
                    die();
                }
            } else if (isset($_POST['multiple'])) {
                $bool = false;
                $test = array();
                foreach ($request->get('idmatch') as $item) {
                    $x = $item;
                    if (array_key_exists($x, $test) == false) {
                        $test[$x] = $item;
                    } else {
                        $bool = true;
                        break;
                    }

                }
                if (($bool == false) && (count($request->get('idmatch')) >= 2) && ($this->getUser()->getJeton() >= $request->get('misetotal'))) {
                    $fp->setCotetotal($request->get('cote'));
                    $fp->setDate(new \DateTime('now'));
                    $fp->setEtat("Encours");
                    $fp->setGain($request->get('gain'));
                    $fp->setMisetotal($request->get('misetotal'));
                    $fp->setType(1);
                    $fp->setIdUser($this->getUser());
                    //Ecriture du nouveau modèle
                    $em = $this->getDoctrine()->getManager();
                    $em->persist($fp);
                    $em->flush();
                    $this->getUser()->setJeton($this->getUser()->getJeton() - $request->get('misetotal'));
                    $em->persist($this->getUser());
                    $em->flush();
                    foreach ($request->get('idmatch') as $k => $item) {
                        $resultat = $request->get('sresultats')[$k];
                        $p = new Pari();
                        $p->setCote(0);
                        $p->setType(0);
                        $p->setGain(0);
                        $p->setEtat("Encours");
                        $p->setMise(0);
                        if ($resultat == "X") {
                            $p->setResultat("X");
                        } else if ($resultat == "1") {
                            $p->setResultat("un");
                        } else if ($resultat == "2") {
                            $p->setResultat("deux");
                        }
                        $match = $em->getRepository("ClientBundle:Match2018")->find($item);
                        $p->setIdMatch($match);
                        $p->setIdFichePari($fp);
                        $em->persist($p);
                        $em->flush();
                    }
                } else {
                    die();
                }
            }


            return $this->redirectToRoute("indexPari");
        }
    }

    public
    function AjouterJournalistePromosportAction(Request $request)
    {
        $bool = false;
        $test = array();
        $fp = new FichePari();
        if ($request->isMethod('POST')) {
            foreach ($request->get('idmatchs') as $item) {
                $x = $item;
                if (array_key_exists($x, $test) == false) {
                    $test[$x] = $item;
                } else {
                    $bool = true;
                    break;
                }
            }

            if ($bool == false && (count($request->get('idmatchs')) >= 6)) {
                $fp->setIdUser($this->getUser());
                $fp->setGain(100);
                $fp->setCotetotal(0);
                $fp->setMisetotal(0);
                $fp->setDate(new \DateTime('now'));
                $fp->setType(3);
                $fp->setEtat("Encours");
                $em = $this->getDoctrine()->getManager();
                $em->persist($fp);
                $em->flush();

                foreach ($request->get('idmatchs') as $k => $item) {
                    $p = new Pari();
                    $p->setCote(-1);
                    $p->setType(-1);
                    $p->setGain(-1);
                    $p->setEtat("Encours");
                    $p->setMise(-1);
                    $p->setResultat("Trois");
                    $match = $em->getRepository("ClientBundle:Match2018")->find($item);
                    $p->setIdMatch($match);
                    $p->setIdFichePari($fp);
                    $em->persist($p);
                    $em->flush();
                }
            } else {
                die();
            }
        }

        return $this->redirectToRoute("journalistePromosport");

    }

    public
    function AjouterMembrePromosportAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $fpp = $em->getRepository("ClientBundle:FichePari")->findBy(array('type' => 3, 'etat' => "Encours"));
        $pp = $em->getRepository("ClientBundle:Pari")->findBy(array('idFichePari' => $fpp));
        $m = "Vous devez parier sur tous les matchs !";
        if ($request->isMethod('POST')) {
            if ((count($request->get('idmatch')) == count($pp))&&($this->getUser()->getJeton()>=$request->get('misetotal'))) {
                $fp = new FichePari();
                $fp->setEtat("Encours");
                $fp->setType("2");
                $fp->setMisetotal($request->get('misetotal'));
                $fp->setCotetotal($request->get('cote'));
                $fp->setGain($request->get('gain'));
                $fp->setDate(new\DateTime('now'));
                $fp->setIdUser($this->getUser());
                $em = $this->getDoctrine()->getManager();
                $em->persist($fp);
                $em->flush();
                $this->getUser()->setJeton($this->getUser()->getJeton() - $request->get('misetotal'));
                $em->persist($this->getUser());
                $em->flush();
                foreach ($request->get('idmatch') as $k => $item) {
                    $resultat = $request->get('sresultats')[$k];
                    $p = new Pari();
                    $p->setCote(0);
                    $p->setType(0);
                    $p->setGain(0);
                    $p->setEtat("Encours");
                    $p->setMise(0);
                    if ($resultat == "X") {
                        $p->setResultat("X");
                    } else if ($resultat == "1") {
                        $p->setResultat("un");
                    } else if ($resultat == "2") {
                        $p->setResultat("deux");
                    }
                    $match = $em->getRepository("ClientBundle:Match2018")->find($item);
                    $p->setIdMatch($match);
                    $p->setIdFichePari($fp);
                    $em->persist($p);
                    $em->flush();
                }

            }
            else {
                die();
            }
        }


        return $this->redirectToRoute("MembrePromosport");


    }

    public function AnnulerPariAdminAction($id){
        $em=$this->getDoctrine()->getManager();
        $fpari = $em->getRepository("ClientBundle:FichePari")->find($id);
        $fpari->setEtat("Annule");
        $em->persist($fpari);
        $em->flush();

        return $this->redirectToRoute("AdminPari");
    }
}
