<?php

namespace ClientBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class Match2018Controller extends Controller
{
    public function indexAction()
    {
        return $this->render('ClientBundle:Match2018:index.html.twig', array(
            // ...
        ));
    }

}
