<?php

namespace ClientBundle\Controller;
use Knp\Snappy\Pdf;
use ClientBundle\Entity\Pari;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\DependencyInjection\Dump\Container;
use Symfony\Component\HttpFoundation\Response;
use Knp\Bundle\SnappyBundle\Snappy\LoggableGenerator;
use Symfony\Component\HttpFoundation\Request;
use Knp\Bundle\SnappyBundle\Snappy\Response\PdfResponse;
use Flosch\Bundle\StripeBundle\Stripe\StripeClient as BaseStripeClient;

class PariController extends Controller
{
    public function indexAction()
    {


        $em = $this->getDoctrine()->getManager();
        $dates = array();
        $match = $em->getRepository("ClientBundle:Match2018")->findAll();
        foreach ($match as $item) {
            $x = $item->getDate()->format('Y-m-d');
            $matchs = $em->getRepository("ClientBundle:Pari")->findMatchbyDateDQL($x);
            if (array_key_exists($x, $dates) == false) {
                $dates[$x] = $matchs;
            }


        }
        return $this->render('@Client/Pari/index.html.twig', array('matchs' => $match, 'dates' => $dates));
    }

    public function AfficherAction()
    {

    }

    public function AjouterAction()
    {

    }

    public function historiqueAction()
    {

        $em = $this->getDoctrine()->getManager();
        $paris = array();
        $fpari = $em->getRepository("ClientBundle:FichePari")->findBy(array('idUser' => $this->getUser()));
        foreach ($fpari as $item) {
            $pari = ($em->getRepository("ClientBundle:Pari")->findBy(array('idFichePari' => $item->getId(),'type'=>['0','1','2'])));
            $paris[$item->getId()] = $pari;

        }

        return $this->render('@Client/Pari/historique.html.twig', array('ficheparis' => $fpari, 'paris' => $paris));

    }

    public function pdfAction($id)
    {
        $em = $this->getDoctrine()->getManager();
        $fpari = $em->getRepository("ClientBundle:FichePari")->find($id);

        $pari = ($em->getRepository("ClientBundle:Pari")->findBy(array('idFichePari' => $fpari)));


        $snappy = $this->get("knp_snappy.pdf");
        $html = $this->renderView("@Client/Pari/pdf.html.twig", array(
            'title' => "Votre fiche de pari au format PDF",
            'paris' => $pari,
            'ficheparis' => $fpari
        ));
        $filename = "custom_pdf_from_twig";
        return new Response(
            $snappy->getOutputFromHtml($html),
            200,
            array(
                'Content-Type' => 'application/pdf',
                'Content-Disposition' => 'inline; filename="' . $filename . '.pdf"'
            )
        );
    }

    public function PromosportJournalisteAction()
    {
        $x = $this->get('ServicePari')->updatepari();
        $y = $this->get('ServicePari')->updateFichePariandUser();
        $em = $this->getDoctrine()->getManager();
        $dates = array();
        $match = $em->getRepository("ClientBundle:Match2018")->findAll();
        foreach ($match as $item) {
            $x = $item->getDate()->format('Y-m-d');
            $matchs = $em->getRepository("ClientBundle:Pari")->findMatchbyDateDQL($x);
            if (array_key_exists($x, $dates) == false) {
                $dates[$x] = $matchs;
            }


        }
        return $this->render('@Client/Pari/PromosportJournaliste.html.twig', array('matchs' => $match, 'dates' => $dates));
    }

    public function StripeAction(Request $request)
    {\Stripe\Stripe::setApiKey("	sk_test_WZSoFUnWMxbH379C3GJz9GAF");

        \Stripe\Charge::create(array(
            "amount" => 200,
            "currency" => "eur",
            "source" => "tok_mastercard" // obtained with Stripe.js
        ));

        return $this->render('@Client/FichePari/Stripe.html.twig');

    }

    public function PromosportMembreAction(){
        $em=$this->getDoctrine()->getManager();
        $fp=$em->getRepository("ClientBundle:FichePari")->findBy(array('type'=>3,'etat'=>"Encours"));
        $p=array();
        foreach ($fp as $item) {
            $x=$em->getRepository("ClientBundle:Pari")->findBy(array('idFichePari'=>$item->getId()));
                $p[] = $x;

        }
        return $this->render('ClientBundle:Pari:PromosportMembre.html.twig',array('paris'=>$p,'fichep'=>$fp));
    }

    public function AdminPariAction(){
        $em=$this->getDoctrine()->getManager();
        $users=$em->getRepository('ClientBundle:User')->findAll();
        $ufp=array();

        foreach ($users as $item) {
            $x=$item->getUsername();
           $fp=$em->getRepository('ClientBundle:FichePari')->findBy(array('idUser'=>$item->getId(),'etat'=>"Encours"));
           $ufp[$x]=$fp;
        }

        return $this->render('ClientBundle:Pari:AdminPari.html.twig',array('fp_users'=>$ufp));
    }
}
