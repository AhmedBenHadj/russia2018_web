<?php

namespace ClientBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class GalleryController extends Controller
{
    public function indexAction()
    {
        return $this->render('ClientBundle:Gallery:index.html.twig', array(
            // ...
        ));
    }

}
