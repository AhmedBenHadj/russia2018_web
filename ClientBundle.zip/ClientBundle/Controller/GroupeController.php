<?php

namespace ClientBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class GroupeController extends Controller
{
    public function indexAction()
    {
        return $this->render('ClientBundle:Groupe:index.html.twig', array(
            // ...
        ));
    }

}
