<?php

namespace ClientBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class EquipeController extends Controller
{
    public function indexAction()
    {
        return $this->render('ClientBundle:Equipe:index.html.twig', array(
            // ...
        ));
    }

}
