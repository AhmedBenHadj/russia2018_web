<?php
/**
 * Created by PhpStorm.
 * User: skanderbejaoui
 * Date: 12/04/2018
 * Time: 00:59
 */

namespace ClientBundle\Repository;


use Doctrine\ORM\EntityRepository;

class FichePariRepository extends EntityRepository
{
    public function findFp($id){
        $query = $this->getEntityManager()->createQuery("SELECT f FROM ClientBundle:FichePari f WHERE f.id LIKE :id")
            ->setParameter('id',$id);
        return $query->getResult();
    }
}