<?php

namespace ClientBundle\Repository;

class PariRepository extends \Doctrine\ORM\EntityRepository{
    public function findMatchbyDateDQL($match){
        $query = $this->getEntityManager()->createQuery("SELECT m FROM ClientBundle:Match2018 m WHERE m.date LIKE :date ORDER BY m.date ASC ")
            ->setParameter('date',"%".$match."%");
        return $query->getResult();
    }

    public function findDatesMatchDQL(){
        $query = $this->getEntityManager()->createQuery("SELECT m.date FROM ClientBundle:Match2018 m ORDER BY m.date ASC ");
        return $query->getResult();
    }


}