<?php
/**
 * Created by PhpStorm.
 * User: skanderbejaoui
 * Date: 12/04/2018
 * Time: 00:11
 */

namespace ClientBundle\Services;


use Symfony\Component\DependencyInjection\Container;
use Symfony\Component\DependencyInjection\ContainerAwareInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

class PariClass implements ContainerAwareInterface
{
    protected $em;

    public function __construct(\Doctrine\ORM\EntityManager $em)
    {
        $this->em = $em;

    }

    public function get_user_et_leur_fiche()
    {
        $users = $this->em->getRepository("ClientBundle:User")->findall();
        $tab = array();
        foreach ($users as $user) {
            $fp = $this->em->getRepository("ClientBundle:FichePari")->findBy(array('idUser' => $user->getId()));
            $tab[$user->getId()] = $fp;
        }

        return $tab;
    }

    public function ifallmatchplayed($FP)
    {
        $paris = $this->em->getRepository('ClientBundle:Pari')->findBy(array('idFichePari' => $FP->getId()));
        foreach ($paris as $pari) {
            $matchs = $this->em->getRepository('ClientBundle:Match2018')->findBy(array('id' => $pari->getIdMatch()));
            foreach ($matchs as $match) {
                if ($match->getEtat() != "Termine") {
                    return false;
                }
            }
        }
        return true;
    }

    public function updatepari()
    {
        $SE = new EquipeService();
        $users = $this->em->getRepository('ClientBundle:User')->findAll();
        foreach ($users as $user) {
            if (array_key_exists($user->getId(), $this->get_user_et_leur_fiche())) {
                foreach ($this->get_user_et_leur_fiche()[$user->getId()] as $fp) {
                    $paris = $this->em->getRepository('ClientBundle:Pari')->findBy(array('idFichePari' => $fp->getId()));
                    foreach ($paris as $pari) {
                        if ($pari->getIdMatch()->getEtat() == "Termine") {
                            if ($SE->Gagnant($pari->getIdMatch(),$this->em)==null){
                                if($pari->getResultat()=="x"){
                                    $pari->setEtat("Gagne");
                                    $this->em->persist($pari);
                                    $this->em->flush();
                                }
                                else{
                                    $pari->setEtat("Perdu");
                                    $this->em->persist($pari);
                                    $this->em->flush();
                                }

                            } else{
                                if ($SE->Gagnant($pari->getIdMatch(),$this->em)==$pari->getIdMatch()->getIdEquipe1()){
                                    if($pari->getResultat()=="un"){
                                        $pari->setEtat("Gagne");
                                        $this->em->persist($pari);
                                        $this->em->flush();
                                    }
                                    else{
                                        $pari->setEtat("Perdu");
                                        $this->em->persist($pari);
                                        $this->em->flush();
                                    }

                                }
                                else if($SE->Gagnant($pari->getIdMatch(),$this->em)==$pari->getIdMatch()->getIdEquipe2()){
                                    if($pari->getResultat()=="deux"){
                                        $pari->setEtat("Gagne");
                                        $this->em->persist($pari);
                                        $this->em->flush();
                                    }
                                    else{
                                        $pari->setEtat("Perdu");
                                        $this->em->persist($pari);
                                        $this->em->flush();
                                    }
                                }

                            }
                        }
                    }
                }
            }
        }
    }

    public function updateFichePariandUser(){
        $aux = false;
        $i = 0;
        $users=$this->em->getRepository('ClientBundle:User')->findAll();
        foreach ($users as $user) {
            if (array_key_exists($user->getId(), $this->get_user_et_leur_fiche())){
                foreach ($this->get_user_et_leur_fiche()[$user->getId()] as $fp) {
                    if($fp->getEtat()=="Encours"){
                        $i=0;
                        $paris = $this->em->getRepository('ClientBundle:Pari')->findBy(array('idFichePari' => $fp->getId()));
                        foreach ($paris as $pari) {

                            if($pari->getIdMatch()->getEtat()=="Termine"){
                                if($pari->getEtat()=="Perdu"){
                                    $fp->setEtat("Perdu");
                                    $this->em->persist($fp);
                                    $this->em->flush();
                                    $aux = true;
                                    break;
                                }
                            }
                        }
                    dump($this->ifallmatchplayed($fp));
                        if($aux==false && $this->ifallmatchplayed($fp)){

                            $fp->setEtat("Gagne");
                            $this->em->persist($fp);
                            $this->em->flush();
                            $user->setJeton($user->getJeton()+$fp->getGain());
                            $this->em->persist($user);
                            $this->em->flush();
                            $number="21628428425";
                            $message="Felicitations ! Vous avez gagné un pari !";
                            $fromName="Russie2018";
                            $sender = $this->container->get('jhg_nexmo_sms');
                            $sender->sendText($number, $message, $fromName);
                        }
                    }
                }
            }
        }
    }

    public function setContainer(ContainerInterface $container = null)
    {
        $this->container = $container;
        return $this;
    }
}
