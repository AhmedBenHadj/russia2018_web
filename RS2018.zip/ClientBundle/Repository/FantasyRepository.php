<?php
/**
 * Created by PhpStorm.
 * User: quickstrikes96
 * Date: 4/11/18
 * Time: 2:10 AM
 */

namespace ClientBundle\Repository;


use Doctrine\ORM\EntityRepository;

class FantasyRepository extends EntityRepository
{


    public function findMyPlayersOrderedDQL(){
        $query=$this->getEntityManager()
            ->createQuery("SELECT j 
                            FROM ClientBundle:JoueurFantasy j
                            ORDER BY j.points DESC ");
        return $query->getResult();
    }
    public function findAdminTeamsOrderedDQL(){
        $query=$this->getEntityManager()
            ->createQuery("SELECT e 
                            FROM ClientBundle:EquipeFantasy e
                            ORDER BY e.totalpoints DESC ");
        return $query->getResult();
    }
}