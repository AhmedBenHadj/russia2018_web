<?php
/**
 * Created by PhpStorm.
 * User: quickstrikes96
 * Date: 4/11/18
 * Time: 11:15 PM
 */

namespace ClientBundle\Repository;

use Doctrine\ORM\EntityRepository;

class JoueurRepository extends EntityRepository
{
    public function findAllPlayersOrderedDQL(){
        $query=$this->getEntityManager()
            ->createQuery("SELECT j 
                            FROM ClientBundle:Joueur j
                            ORDER BY j.prix DESC ");
        return $query->getResult();
    }
}