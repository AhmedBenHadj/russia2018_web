<?php

namespace ClientBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class FichePariController extends Controller
{
    public function indexAction()
    {
        return $this->render('ClientBundle:FichePari:index.html.twig', array(
            // ...
        ));
    }

}
