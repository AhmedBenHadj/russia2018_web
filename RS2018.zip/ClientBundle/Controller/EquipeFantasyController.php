<?php

namespace ClientBundle\Controller;

use ClientBundle\Form\EquipeFantasyForm;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use ClientBundle\Entity\EquipeFantasy;
use Symfony\Component\HttpFoundation\Request;

class EquipeFantasyController extends Controller
{
    public function indexAction()
    {
        $em=$this->getDoctrine()->getManager();
        $joueur=$em->getRepository("ClientBundle:Joueur")->findAllPlayersOrderedDQL();
        return $this->render('@Client/EquipeFantasy/index.html.twig',array('joueurs'=>$joueur));

    }


    public function CreerEquipeFantasyAction(Request $request)
    {
        $equipefantasy=new EquipeFantasy();
        $Form=$this->createForm(EquipeFantasyForm::class, $equipefantasy);
        $Form->handleRequest($request);
            if ($Form->isValid())
            {
                $equipefantasy->setTotalpoints(0);
                $equipefantasy->setClassement(0);
                $equipefantasy->setTransfers(0);
                $equipefantasy->setValeur(0);
                $equipefantasy->setBanque(100);
                $em=$this->getDoctrine()->getManager();
                $em->persist($equipefantasy);
                $em->flush();
                return $this->redirectToRoute('indexEquipeFantasy');
            }

        return $this->render('@Client/EquipeFantasy/ajout.html.twig',array('form'=>$Form->createView()));

    }

    public function MonEquipeFantasyAction()
    {
        $em=$this->getDoctrine()->getManager();
        return $this->render('@Client/JoueurFantasy/myteam.html.twig',array());

    }
}
