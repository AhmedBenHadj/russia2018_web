<?php

namespace ClientBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class DefaultController extends Controller
{
    public function indexAction()
    {

        return $this->render('ClientBundle:Default:index.html.twig');
    }
    public function dashboardAction()
    {

        return $this->render('@Client/Default/dashboard.html.twig');
    }
    public function fantasydashboardAction()
    {
        $em=$this->getDoctrine()->getManager();
        $equipesfantasy=$em->getRepository('ClientBundle:EquipeFantasy')->findAdminTeamsOrderedDQL();
        return $this->render('@Client/JoueurFantasy/teams admin.html.twig',array('equipes'=>$equipesfantasy));
    }
}
