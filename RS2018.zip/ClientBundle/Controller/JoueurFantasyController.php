<?php

namespace ClientBundle\Controller;

use ClientBundle\Entity\JoueurFantasy;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;



class JoueurFantasyController extends Controller
{
    public function indexAction()
    {
        $em=$this->getDoctrine()->getManager();
        $joueursfantasy=$em->getRepository('ClientBundle:JoueurFantasy')->findMyPlayersOrderedDQL();
        return $this->render('@Client/EquipeFantasy/myteam.html.twig',array('skander'=>$joueursfantasy));
    }

    public function index1Action()
    {
        $em=$this->getDoctrine()->getManager();
        $joueursfantasy=$em->getRepository('ClientBundle:JoueurFantasy')->findMyPlayersOrderedDQL();
        return $this->render('@Client/EquipeFantasy/myteam.html.twig',array('team'=>$joueursfantasy));
    }

    public function AjouterJoueurFantasyAction(Request $request)
    {

            $joueurfantasy = new JoueurFantasy();
            if ($request->isMethod('POST')) {
                for ($i = 1; $i <= 15; $i++) {
                $em = $this->getDoctrine()->getManager();
                $j = $em->getRepository('ClientBundle:Joueur')->find($request->request->get('p'.$i.''));
                $joueurfantasy->setIdJoueur($j);
                //$joueurfantasy->setIdEquipe();
                $joueurfantasy->setEtat(1);
                $joueurfantasy->setPoints(0);

                $em->persist($joueurfantasy);
                $em->flush();
                return $this->redirectToRoute('indexJoueurFantasy');


            }

            return $this->render('@Client/EquipeFantasy/index.html.twig', array());
        }
    }
}
